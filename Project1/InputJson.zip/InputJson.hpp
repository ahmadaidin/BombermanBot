//#pragma once

#include <iostream>
#include <string>
#include "../Map/Entities/Player.hpp"
#include "../Map/Entity.hpp"
using namespace std;
