
#include <iostream>
#include <string>
#include "json.h"
#include <fstream>
#include "../Map/Entities/Player.hpp"
#include "../Map/Entities/Bomb.hpp"
#include "../Map/Block.hpp"
#include "../Map/Entity.hpp"
#include "../Map/Location.hpp"

using namespace std;

string ReadJson(string filePath) {
	cout << "Reading state file " << filePath << endl;
	string fileContent;
	string line;
	ifstream myfile(filePath);
	if (myfile.is_open())
	{
		while (getline(myfile, line))
		{
			fileContent += line += "\n";
		}
		myfile.close();
	}
	return fileContent;
}

vector<Player> getAllPlayer(Json::Value obj){
	std::vector<Player> allPlayer;
	Json::Value REP = obj["RegisteredPlayerEntities"];
	for (int i = 0; i < REP.size(); i++) {
		string name = REP[i]["Name"].asString();
		char key= REP[i]["Key"].asCString();
		int points= REP[i]["Points"].asInt();
		int BombBag= REP[i]["BombBag"].asInt();
		int BombRadius= REP[i]["BombRadius"].asInt();
		int x = REP[i]["Location"]["X"].asInt();
		int y =  REP[i]["Location"]["Y"].asInt();
		Location location(x,y);
		Player *p = new Player(location, name, key, points, BombBag, BombRadius);
		allPlayer.push_back(*p);
}

int getCurrentRound(Json::Value obj){
	return obj["CurrentRound"].asString();
}

int getPlayerBounty(Json::Value obj){
	return obj["PlayerBounty"].asString();
}
	
int MapHeight(Json::Value obj){
	return obj["MapHeight"].asString();
}

int MapWidth(Json::Value obj){
	return obj["MapWidth"].asString();
}

vector<<vector<Block>> GetAllGameBlock(Json::Value obj){
	std::vector<Block> allBlock;
	Json::Value B = obj["RegisteredPlayerEntities"];
	for (int i = 0; i < Block.size(); i++) {
		string type = B[i]["$type"].asString();
		int x1 = B[i]["X"].asInt();
		int y1 = B[i]["Y"].asInt();
		Location Loc1(x1,y1);
		Entity entity(type, Loc1);
		if (!obj["Bomb"].isnull()) {
			string name = B[i]["Name"].asString();
			char key = B[i]["Key"].asCString();
			int points = B[i]["Points"].asInt();
			bool killed = B[i]["Killed"].asBool();
			int BombBag= B[i]["BombBag"].asInt();
			int BombRadius= B[i]["BombRadius"].asInt();
			int x3 = B[i]["X"].asInt();
			int y3 = B[i]["Y"].asInt();
			Location Loc3(x3,y3);
			Player owner(loc3, name, key, points, BombBag, BombRadius);
			int BombRadius= B[i]["BombRadius"].asInt();
			int BombTimer= B[i]["BombTimer"].asInt();
			bool IsExploding= B[i]["IsExploding"].asBool();
			int x4 = B[i]["X"].asInt();
			int y4 = B[i]["Y"].asInt();
			Location Loc4(x4,y4);
			Bomb bomb(Loc4, owner, BombTimer, IsExploding, BombRadius);
		} 
		if (!(obj["PowerUp"].isnull())) {
			string type = B[i]["$type"].asString();
			int x5 = B[i]["X"].asInt();
			int y5 = B[i]["Y"].asInt();
			Location Loc5(x5,y5);
			PowerUp * powerup(type, Loc5);
		} 
		string P = B[i]["PowerUp"].asString();
		bool e = B[i]["Exploding"].asBool();
		int x2= B[i]["X"].asInt();
		int y2 = B[i]["Y"].asInt();
		Location Loc2(x2,y2);
	}
	Block *b = new Block(Loc2, entity, Bomb, PowerUp);
	allBlock.push_back();
}

double MapSeed(Json::Value obj) {
	return obj["MapSeed"].asDouble();
}

int main() {
  string str;
  str = ReadJson("state.json");
  Json::Reader reader;
  Json::Value obj;
  reader.parse(str, obj);
  cOut<<"Haha"<<endl;
  return 0;
}